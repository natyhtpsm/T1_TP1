var searchData=
[
  ['unb_0',['Trabalho 1 - Técnicas de Programação 1 (UnB)',['../md__r_e_a_d_m_e.html',1,'']]],
  ['utilizados_1',['💻 Domínios e Métodos Utilizados',['../md__r_e_a_d_m_e.html#autotoc_md3',1,'']]]
];
