var indexSectionsWithContent =
{
  0: "1cdefgmnpstu💻📖📝📦🚀",
  1: "cdenpst",
  2: "gs",
  3: "1dptu"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions",
  3: "pages"
};

var indexSectionLabels =
{
  0: "Todos",
  1: "Classes",
  2: "Funções",
  3: "Páginas"
};

