var searchData=
[
  ['💻_20domínios_20e_20métodos_20utilizados_0',['💻 Domínios e Métodos Utilizados',['../md__r_e_a_d_m_e.html#autotoc_md3',1,'']]]
];
